#include "OgreMDIChildFrame.h"
#include "OgreMainWindow.h"
#include "wxOgreCtrl.h"

namespace RAGE {


BEGIN_EVENT_TABLE(OgreMDIChildFrame, wxMDIChildFrame)
    EVT_CLOSE(OgreMDIChildFrame::OnClose)
END_EVENT_TABLE()

OgreMDIChildFrame::OgreMDIChildFrame(wxMDIParentFrame* parent, 
				wxWindowID id, 
				const wxString& title, 
				const wxPoint& pos, 
				const wxSize& size, 
				long style, 
				const wxString& name,
				Ogre::SceneManager* sceneManager) : wxMDIChildFrame(parent,id,title,pos,size,style,name) {

	renderTarget_ = new wxOgreCtrl(this, 
					wxID_ANY, 
					wxDefaultPosition,
					wxDefaultSize, 
					wxDEFAULT_FRAME_STYLE, 
					name,
					sceneManager);

}

OgreMDIChildFrame::~OgreMDIChildFrame() {
	renderTarget_->finalizeOgre();
}

void OgreMDIChildFrame::OnClose(wxCloseEvent& event) {
	this->Show(false);
	OgreMainWindow* win = dynamic_cast<OgreMainWindow*>(this->GetParent());
	if (win)
		win->updateMenuChildFrameShowHide(this->GetTitle());
}

void OgreMDIChildFrame::update() {
	renderTarget_->update();
}

wxOgreCtrl* OgreMDIChildFrame::getRenderTarget() {
	return renderTarget_;
}

}
