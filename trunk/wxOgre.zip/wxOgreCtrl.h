#ifndef wxOgreCtrl_H_
#define wxOgreCtrl_H_

#include <wx/wx.h>
#include <Ogre.h>
#include <rage/thread/rageSync.h>
#include <rage/ogre/OgreFrontend.h>

//#include <rage/thread/WorkerThread.h>
//#include <OgreEventListeners.h>
//#define OIS_DYNAMIC_LIB
//#include <OIS/OIS.h>

typedef struct {
	Ogre::Vector3 pos;
	Ogre::Vector3 dir;
} cameraLocTp;


class wxOgreCtrl : public wxControl/*, public OIS::MouseListener, public RAGE::WorkerThread*/ {
	rageSYNCHRONIZED_CLASS
public:

	wxOgreCtrl();

	wxOgreCtrl(wxWindow* parent, 
				wxWindowID id = wxID_ANY, 
				const wxPoint& pos = wxDefaultPosition, 
				const wxSize& size = wxDefaultSize, 
				long style = 0, 
				const wxString& name = wxPanelNameStr,
				Ogre::SceneManager* sceneManager = NULL);

	virtual ~wxOgreCtrl();

	void finalizeOgre();

	void OnSize(wxSizeEvent& event);

	void OnMouseLeftDownEvent(wxMouseEvent& event);
	void OnMouseMiddleDownEvent(wxMouseEvent& event);
	void OnMouseRightDownEvent(wxMouseEvent& event);
	void OnMouseMovedEvent(wxMouseEvent& event);
	void OnMouseWheelEvent(wxMouseEvent& event);
	void OnKeyPressed(wxKeyEvent& event);
	void OnKeyReleased(wxKeyEvent& event);

	/*bool mouseMoved( const OIS::MouseEvent &arg );
	bool mousePressed( const OIS::MouseEvent &arg, OIS::MouseButtonID id );
	bool mouseReleased( const OIS::MouseEvent &arg, OIS::MouseButtonID id );*/

	void setFreeze(const bool& freeze = true);
	void showDebugOverlay(const bool& show = true);
	void setCameraPosition(double x, double y, double z);
	void setCameraDirection(double x, double y, double z);
	void setCameraLookAt(double x, double y, double z);

	Ogre::Camera* getCamera(){return camera_;}

	// renders a frame
	void update();

	void initializeOIS();

	DECLARE_DYNAMIC_CLASS(wxOgreCtrl)
	DECLARE_EVENT_TABLE()


private:

	// Ogre stuff
	Ogre::SceneManager*  sceneMgr_;
	Ogre::String         ogreWidgetName_;
	Ogre::RenderWindow*  renderWindow_;
	Ogre::Camera*        camera_;
	Ogre::Viewport*      vp_;

	// Debug overlay
	Ogre::Overlay* debugOverlay_;

	// Camera interaction stuff
	/*bool				mouseLeftPressed_;
	bool				mouseRightPressed_;
	bool				mouseMiddlePressed_;*/
	wxPoint				mousePressPos_;
	Ogre::Radian		rotX_, rotY_;
	Ogre::Real			transX_, transY_, transZ_;
	Ogre::Real			deltaX_, deltaZ_;
	Ogre::Real			speed_;

	Ogre::Real			rotate_;
	Ogre::Real			translate_;
	Ogre::Real			translate_key_;

	Ogre::String		cameraDetails_;
	std::vector<cameraLocTp>	cameraLocations_;

	bool freeze_;
	bool ogreFinalized_;

	int sceneDetail_;
	int numScreenShots_;

	void updateDebugOverlay();

	//OIS STUFF
	//OIS::Mouse*    mouse_;
	//OIS::InputManager* inputManager_ ;



};

#endif