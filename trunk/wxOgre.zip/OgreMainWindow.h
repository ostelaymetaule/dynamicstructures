#ifndef OgreMainWindow_H_
#define OgreMainWindow_H_

#include <wx/mdi.h>
#include <wx/wx.h>

#include <libmath/Vector3D.h>
#include <rage/rageSystemDefinitions.h>


class wxOgreCtrl;

namespace Ogre {
	class SceneManager;
	class Root;
}

namespace RAGE {

class RAGELIBDECL OgreMainWindow : public wxMDIParentFrame {
	//rageSYNCHRONIZED_CLASS
public:

    OgreMainWindow();

    OgreMainWindow(wxWindow *parent, const wxWindowID id, const wxString& title,
            const wxPoint& pos, const wxSize& size, const long style);

	virtual ~OgreMainWindow();

	void OnClose(wxCloseEvent& event);
    void OnSize(wxSizeEvent& event);
	void OnShowHideChildFrame(wxCommandEvent& event);
	//void OnCreate(wxWindowCreateEvent& event);

	// Ogre initialization stuff
	void addRenderingSubSystemParameter(const std::string& subsystem, const std::string& name, const std::string& value);
	void setRenderingSubSystem(const std::string& rss);
	void setOgrePluginFolder(const std::string& folder);
	void setOgreLogLevel(const std::string& level);
	void addOgrePlugin(const std::string& pluginName);
	void addResourceLocation(const std::string& name, const std::string& type, const std::string& group);

	void disconnectIdleLoop();
	void createWindow(const std::string& title, int width, int height);
    void OnIdle(wxIdleEvent& event);

	void updateMenuChildFrameShowHide(const wxString& title);

	virtual Ogre::SceneManager* getSceneManager() const;
	virtual Ogre::Root*         getRoot() const;

	virtual void		setCameraPosition(const std::string& title, double x, double y, double z);
	virtual void		setCameraDirection(const std::string& title, double x, double y, double z);
	virtual void		setCameraLookAt(const std::string& title, double x, double y, double z);

	virtual MATH::Vector3D	doIntersection(const std::string& title, int x, int y) ;
	virtual MATH::Vector3D	doIntersectionWithGroundPlane(const std::string& title, int x, int y) ;


	wxOgreCtrl* getRenderTarget(const std::string& title);

	void enableRendering(const bool& render = true);

	void waitForOgreInitialized();


    DECLARE_EVENT_TABLE()

private:

	class PIMPL;
	PIMPL* pImpl_;


	void createMDIChild();

	wxMenu* view_menu_;




};

}

#endif