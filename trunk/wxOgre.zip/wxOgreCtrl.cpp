#include "wxOgreCtrl.h"

#include <rage/log/Log.h>
#include <rage/rageString.h>
#include <rage/event/EventManager.h>
#include <rage/kernel/Kernel.h>
//#include <rage/runtime/RuntimeEngine.h>
#include <rage/ogre/OgreKeyPressedEvent.h>
#include <rage/ogre/OgreKeyReleasedEvent.h>
#include <rage/ogre/OgreMouseClickedEvent.h>

#include <OgreString.h>


BEGIN_EVENT_TABLE(wxOgreCtrl, wxControl)
	EVT_SIZE(wxOgreCtrl::OnSize)
	EVT_LEFT_DOWN(wxOgreCtrl::OnMouseLeftDownEvent)
	EVT_MIDDLE_DOWN(wxOgreCtrl::OnMouseMiddleDownEvent)
	EVT_RIGHT_DOWN(wxOgreCtrl::OnMouseRightDownEvent)
	EVT_MOTION(wxOgreCtrl::OnMouseMovedEvent)
	EVT_MOUSEWHEEL(wxOgreCtrl::OnMouseWheelEvent)
	EVT_KEY_DOWN(wxOgreCtrl::OnKeyPressed)
	EVT_KEY_UP(wxOgreCtrl::OnKeyReleased)
END_EVENT_TABLE()

IMPLEMENT_DYNAMIC_CLASS(wxOgreCtrl, wxControl)

wxOgreCtrl::wxOgreCtrl() : wxControl() {
}

wxOgreCtrl::wxOgreCtrl(wxWindow* parent, 
				wxWindowID id, 
				const wxPoint& pos, 
				const wxSize& size, 
				long style, 
				const wxString& name,
				Ogre::SceneManager* sceneManager) : wxControl(parent, id, pos, size, style, wxDefaultValidator, name) {

	sceneMgr_ = sceneManager;
	ogreWidgetName_ = name.ToAscii();
	
	RAGE::Kernel::instance()->getEventManager()->registerEvent<RAGE::OgreMouseClickedEvent>();
	RAGE::Kernel::instance()->getEventManager()->registerEvent<RAGE::OgreKeyPressedEvent>();
	RAGE::Kernel::instance()->getEventManager()->registerEvent<RAGE::OgreKeyReleasedEvent>();

	// Create a new parameters list according to compiled OS
	Ogre::NameValuePairList params;
	Ogre::String handle;
	handle = Ogre::StringConverter::toString((size_t)((HWND)GetHandle()));
	params["externalWindowHandle"] = handle;

	// Get wx control window size
	int width;
	int height;
	GetSize(&width, &height);

	// Create the render window
	ragePLUGINLOG << "Creating Ogre render window with name [" << name << "]";
	renderWindow_ = Ogre::Root::getSingleton().createRenderWindow(ogreWidgetName_, width, height, false, &params);

	// Create the camera
	camera_ = sceneMgr_->createCamera(ogreWidgetName_+"Cam");
	rageLIBLOG << "Camera created with name: " << (ogreWidgetName_+"Cam");
	camera_->setPosition(Ogre::Vector3(0,0,200));
	camera_->lookAt(Ogre::Vector3(0,0,0));
	camera_->setNearClipDistance(5);

	// Fill all camera locations with the current location
	for (int i=0; i<10; i++) {
		cameraLocTp cl;
		cl.dir = camera_->getDirection();
		cl.pos = camera_->getPosition();
		cameraLocations_.push_back(cl);
	}

	vp_ = renderWindow_->addViewport(camera_);
	vp_->setBackgroundColour(Ogre::ColourValue(0,0,0));
	vp_->setOverlaysEnabled(false);
	camera_->setAspectRatio(Ogre::Real(vp_->getActualWidth()) / Ogre::Real(vp_->getActualHeight()));
	Ogre::MaterialManager::getSingleton().setDefaultTextureFiltering(Ogre::TFO_BILINEAR);
	Ogre::MaterialManager::getSingleton().setDefaultAnisotropy(1);

	// get the debug overlay
	debugOverlay_ = Ogre::OverlayManager::getSingleton().getByName("Core/DebugOverlay");
	debugOverlay_->show();

	rotate_ = 0.2;
	//translate_ = 0.05;
	translate_ = 1.0;
	translate_key_ = 0.2;
	mousePressPos_.x = 0;
	mousePressPos_.y = 0;

	rotX_   = 0.0;
	rotY_   = 0.0;
	transX_ = 0.0;
	transY_ = 0.0;
	transZ_ = 0.0;
	deltaX_ = 0.0;
	deltaZ_ = 0.0;
	speed_ = 1.0;

	freeze_ = false;
	ogreFinalized_ = false;

	sceneDetail_ = 0;
	numScreenShots_ = 0;
	cameraDetails_ = "";
}

/*void wxOgreCtrl::initializeOIS(){
	OIS::ParamList pl;
	size_t windowHnd = 0;
	std::ostringstream windowHndStr;
	renderWindow_->getCustomAttribute("WINDOW", &windowHnd);

	Ogre::String handle;
	handle = Ogre::StringConverter::toString((size_t)((HWND)GetHandle()));
	windowHndStr << windowHnd;
	std::string windowHndString = windowHndStr.str();
	pl.insert(std::make_pair(std::string("WINDOW"), windowHndString));
	inputManager_ = OIS::InputManager::createInputSystem( pl );

	//this->SetFocus();
	//this->Show();
	
	//Create all devices 
	
	//OIS::Object* oisObject = inputManager_->createInputObject(OIS::OISMouse, true);
	//mouse_ = dynamic_cast<OIS::Mouse*>(oisObject);
	
	mouse_ = static_cast<OIS::Mouse*>(inputManager_->createInputObject( OIS::OISMouse, true ));
	mouse_->setEventCallback(this);
}
*/
wxOgreCtrl::~wxOgreCtrl() {
}

/*bool wxOgreCtrl::mouseMoved( const OIS::MouseEvent &arg ){
	return true;
}
bool wxOgreCtrl::mousePressed( const OIS::MouseEvent &arg, OIS::MouseButtonID id ){
	rageLIBLOG << "Yet another mouse pressed";
	return true;
}
bool wxOgreCtrl::mouseReleased( const OIS::MouseEvent &arg, OIS::MouseButtonID id ){
	return true;
}*/

void wxOgreCtrl::finalizeOgre() {
	rageSYNCHRONIZED;
	if (vp_) {
		renderWindow_->removeViewport(vp_->getZOrder());
		vp_ = 0;
	}
	Ogre::Root::getSingleton().detachRenderTarget(renderWindow_);
	renderWindow_ = 0;
	ogreFinalized_ = true;
}


void wxOgreCtrl::OnSize(wxSizeEvent& event) {
	rageSYNCHRONIZED;

	if (ogreFinalized_)
		return;

	// get the new width and height
	int width;
	int height;
	GetSize(&width, &height);

	// resize the render window
	renderWindow_->resize( width, height );
	renderWindow_->windowMovedOrResized();

	// set the camera aspect ratio for the new size
	camera_->setAspectRatio(Ogre::Real(width) / Ogre::Real(height));
}

void wxOgreCtrl::update() {
	rageSYNCHRONIZED;
	if (freeze_ || ogreFinalized_)
		return;

	camera_->yaw(rotX_);
	camera_->pitch(rotY_);
	camera_->moveRelative(Ogre::Vector3(transX_ + deltaX_ * speed_, transY_, transZ_ + deltaZ_ * speed_));

	// update camera details
	if (cameraDetails_ != "")
		cameraDetails_ = "P: " + Ogre::StringConverter::toString(camera_->getDerivedPosition()) +
		" " + "O: " + Ogre::StringConverter::toString(camera_->getDerivedOrientation()) + "D: " + Ogre::StringConverter::toString(camera_->getDerivedDirection());
				

	renderWindow_->update();

	this->updateDebugOverlay();

	rotX_ = 0;
	rotY_ = 0;
	transX_ = 0;
	transY_ = 0;
	transZ_ = 0;

}

void wxOgreCtrl::setCameraPosition(double x, double y, double z){
	rageSYNCHRONIZED;
	if (ogreFinalized_)
		return;
	camera_->setPosition(x, y, z);
}

void wxOgreCtrl::setCameraDirection(double x, double y, double z){
	rageSYNCHRONIZED;
	if (ogreFinalized_)
		return;
	camera_->setDirection(x, y, z);
}

void wxOgreCtrl::setCameraLookAt(double x, double y, double z){
	rageSYNCHRONIZED;
	if (ogreFinalized_)
		return;
	camera_->lookAt(x, y, z);
}

void wxOgreCtrl::setFreeze(const bool& freeze) {
	rageSYNCHRONIZED;
	if (ogreFinalized_)
		return;
	freeze_ = freeze;
	if (freeze)
		renderWindow_->setVisible(false);
	else
		renderWindow_->setVisible(true);
}


void wxOgreCtrl::OnMouseLeftDownEvent(wxMouseEvent& event) {
	rageSYNCHRONIZED;
	if (ogreFinalized_)
		return;
	mousePressPos_ = event.GetPosition();
	rageLIBLOG << "MOUSE LEFT DOWN";
	
	
	RAGE::EventManager* eventManager = RAGE::Kernel::instance()->getEventManager();
	eventManager->postEvent(new RAGE::OgreMouseClickedEvent(RAGE::LEFTCLICKED, mousePressPos_.x, mousePressPos_.y));

}


void wxOgreCtrl::OnMouseMiddleDownEvent(wxMouseEvent& event) {
	rageSYNCHRONIZED;
	if (ogreFinalized_)
		return;
	mousePressPos_ = event.GetPosition();
	rageLIBLOG << "MOUSE MIDDLE DOWN";
	
	RAGE::EventManager* eventManager = RAGE::Kernel::instance()->getEventManager();
	eventManager->postEvent(new RAGE::OgreMouseClickedEvent(RAGE::MIDDLECLICKED, mousePressPos_.x, mousePressPos_.y));
}

void wxOgreCtrl::OnMouseRightDownEvent(wxMouseEvent& event) {
	rageSYNCHRONIZED;
	if (ogreFinalized_)
		return;
	mousePressPos_ = event.GetPosition();
	rageLIBLOG << "MOUSE RIGHT DOWN";
	
	RAGE::EventManager* eventManager = RAGE::Kernel::instance()->getEventManager();
	eventManager->postEvent(new RAGE::OgreMouseClickedEvent(RAGE::RIGHTCLICKED, mousePressPos_.x, mousePressPos_.y));

}

void wxOgreCtrl::OnMouseMovedEvent(wxMouseEvent& event) {
	rageSYNCHRONIZED;
	if (ogreFinalized_)
		return;
	if (!event.Dragging())
		return;

	wxPoint relPos = event.GetPosition() - mousePressPos_;
	mousePressPos_ = event.GetPosition();

	if(event.LeftIsDown()){

		if (abs(relPos.x)>1)
			rotX_ += Ogre::Degree(relPos.x * -rotate_);
		if (abs(relPos.y)>1)
			rotY_ += Ogre::Degree(relPos.y * -rotate_);

	} else if (event.RightIsDown()) {

		if (abs(relPos.x)>1)
			transX_ += relPos.x * -translate_;
		if (abs(relPos.y)>1)
			transY_ += relPos.y * translate_;

	} else if (event.MiddleIsDown()) {

		if (abs(relPos.y)>1)
			transZ_ += relPos.y * translate_;

	}
}

void wxOgreCtrl::OnKeyPressed(wxKeyEvent& event) {
	rageSYNCHRONIZED;
	if (ogreFinalized_)
		return;
	if (event.GetKeyCode() == WXK_UP)
		deltaZ_ = -translate_key_;
	else if (event.GetKeyCode() == WXK_DOWN)
		deltaZ_ = translate_key_;
	else if (event.GetKeyCode() == WXK_LEFT)
		deltaX_ = -translate_key_;
	else if (event.GetKeyCode() == WXK_RIGHT)
		deltaX_ = translate_key_;
	else if (event.GetKeyCode() == WXK_SHIFT)
		speed_ = 10.0;
	else if (event.GetKeyCode() == 68) { // D for showing/hiding debug overlay
		if (vp_->getOverlaysEnabled())
			showDebugOverlay(false);
		else
			showDebugOverlay(true);
	} else if (event.GetKeyCode() == 87) { // W for wireframe/scene detail
		sceneDetail_ = (sceneDetail_+1)%3;
		switch(sceneDetail_) {
			case 0 : camera_->setPolygonMode(Ogre::PM_SOLID); break;
			case 1 : camera_->setPolygonMode(Ogre::PM_WIREFRAME); break;
			case 2 : camera_->setPolygonMode(Ogre::PM_POINTS); break;
		}
	} else if (event.GetKeyCode() == 83) { // S for saving a screenshot
		std::ostringstream ss;
		ss << ogreWidgetName_ << "_screenshot_" << ++numScreenShots_ << ".png";
		renderWindow_->writeContentsToFile(ss.str());
		ragePLUGINLOG << "Saved a screenshot: " << ss.str();
	} else if (event.GetKeyCode() == WXK_PAUSE) { // freeze
		if (this->freeze_)
			this->setFreeze(false);
		else
			this->setFreeze(true);
	} else if (event.GetKeyCode() == 67) { // C for printing camera details in debug overlay
		if (cameraDetails_ == "")
			cameraDetails_ = "P: " + Ogre::StringConverter::toString(camera_->getPosition()) +
			" " + "O: " + Ogre::StringConverter::toString(camera_->getDirection());
		else
			cameraDetails_ = "";
	} else if (event.GetKeyCode() >=48 && event.GetKeyCode() <= 57) { // camera management
		int cameraNr = event.GetKeyCode() - 48;
		if (event.AltDown()) { // save the current camera location
			cameraLocations_[cameraNr].dir = camera_->getDirection();
			cameraLocations_[cameraNr].pos = camera_->getPosition();
			ragePLUGINLOG << "Saved camera location to slot " << cameraNr;
		} else { // retrieve the camera location from the location vector
			camera_->setDirection(cameraLocations_[cameraNr].dir);
			camera_->setPosition(cameraLocations_[cameraNr].pos);
			ragePLUGINLOG << "Retrieved camera location from slot " << cameraNr;
		}
	}
	RAGE::EventManager* eventManager = RAGE::Kernel::instance()->getEventManager();
	eventManager->postEvent(new RAGE::OgreKeyPressedEvent(wxKeyCode(event.GetKeyCode())));

}

void wxOgreCtrl::OnKeyReleased(wxKeyEvent& event) {
	rageSYNCHRONIZED;
	if (ogreFinalized_)
		return;
	if (event.GetKeyCode() == WXK_UP || event.GetKeyCode() == WXK_DOWN)
		deltaZ_ = 0.0;
	else if (event.GetKeyCode() == WXK_LEFT || event.GetKeyCode() == WXK_RIGHT)
		deltaX_ = 0.0;
	else if (event.GetKeyCode() == WXK_SHIFT)
		speed_ = 1.0;
	RAGE::EventManager* eventManager = RAGE::Kernel::instance()->getEventManager();
	eventManager->postEvent(new RAGE::OgreKeyReleasedEvent(wxKeyCode(event.GetKeyCode())));
}

void wxOgreCtrl::OnMouseWheelEvent(wxMouseEvent& event) {
	rageSYNCHRONIZED;
	if (ogreFinalized_)
		return;
	transZ_ += translate_ * event.GetWheelRotation();
}

void wxOgreCtrl::showDebugOverlay(const bool& show)	{
	rageSYNCHRONIZED;
	if (ogreFinalized_)
		return;
	if (show)
		vp_->setOverlaysEnabled(true);
	else
		vp_->setOverlaysEnabled(false);
}

void wxOgreCtrl::updateDebugOverlay() {
	if (!vp_->getOverlaysEnabled())
		return;

	Ogre::String currFps	= "Current FPS: ";
	Ogre::String avgFps		= "Average FPS: ";
	Ogre::String bestFps	= "Best FPS: ";
	Ogre::String worstFps	= "Worst FPS: ";
	Ogre::String tris		= "Triangle Count: ";
	Ogre::String batches	= "Batch Count: ";

	// update stats when necessary
	try {
		Ogre::OverlayElement* guiAvg = Ogre::OverlayManager::getSingleton().getOverlayElement("Core/AverageFps");
		Ogre::OverlayElement* guiCurr = Ogre::OverlayManager::getSingleton().getOverlayElement("Core/CurrFps");
		Ogre::OverlayElement* guiBest = Ogre::OverlayManager::getSingleton().getOverlayElement("Core/BestFps");
		Ogre::OverlayElement* guiWorst = Ogre::OverlayManager::getSingleton().getOverlayElement("Core/WorstFps");
		Ogre::OverlayElement* guiTris = Ogre::OverlayManager::getSingleton().getOverlayElement("Core/NumTris");
		Ogre::OverlayElement* guiBatches = Ogre::OverlayManager::getSingleton().getOverlayElement("Core/NumBatches");
		Ogre::OverlayElement* guiDbg = Ogre::OverlayManager::getSingleton().getOverlayElement("Core/DebugText");
		const Ogre::RenderTarget::FrameStats& stats = renderWindow_->getStatistics();
		
		guiAvg->setCaption(avgFps + Ogre::StringConverter::toString(stats.avgFPS));
		guiCurr->setCaption(currFps + Ogre::StringConverter::toString(stats.lastFPS));
		guiBest->setCaption(bestFps + Ogre::StringConverter::toString(stats.bestFPS)
				+" "+Ogre::StringConverter::toString(stats.bestFrameTime)+" ms");
		guiWorst->setCaption(worstFps + Ogre::StringConverter::toString(stats.worstFPS)
				+" "+Ogre::StringConverter::toString(stats.worstFrameTime)+" ms");
		guiTris->setCaption(tris + Ogre::StringConverter::toString(stats.triangleCount));
		guiBatches->setCaption(batches + Ogre::StringConverter::toString(stats.batchCount));
		guiDbg->setCaption(cameraDetails_);

	} catch(...) { /* ignore */ }
}
