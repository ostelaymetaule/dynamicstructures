#include "OgreMainWindow.h"
#include "OgreMDIChildFrame.h"
//#include "IPluginMDIGUI.h"

#include <wx/wx.h>
#include <wx/laywin.h>

#include "wxDummyOgreCtrl.h"
#include "wxOgreCtrl.h"
#include <rage/exception/rageException.h>
#include <rage/kernel/Kernel.h>
#include <rage/log/Log.h>

#include <OgreRoot.h>
#include <OgreLog.h>
#include <OgreSceneManager.h>
#include <OgreException.h>
#include <OgreLogManager.h>
#include <OgreRenderSystem.h>


namespace RAGE {

BEGIN_EVENT_TABLE(OgreMainWindow, wxMDIParentFrame)
    EVT_SIZE(OgreMainWindow::OnSize)
    EVT_CLOSE(OgreMainWindow::OnClose)
	//EVT_IDLE(PluginMainWindow::OnIdle)
	//EVT_WINDOW_CREATE(OgreMainWindow::OnCreate)
END_EVENT_TABLE()


	// class for representing a render subsystem parameter
	class rssParamTp {
	public:
		rssParamTp(const std::string& subsystem, const std::string& name, const std::string& value) :
		  subsystem_(subsystem), name_(name), value_(value) {}

		std::string subsystem_;
		std::string name_;
		std::string value_;
	};




class OgreMainWindow::PIMPL : public Ogre::LogListener {
public:

	PIMPL(OgreMainWindow* gui) : gui_(gui) {

		windowCreationFinished_ = true;
		currWidth_ = 200;
		currHeight_ = 200;
		disconnectIdleLoop_ = false;
		sceneManager_ = NULL;
		ogrePluginFolder_ = ".";
		ogreLogLevel_ = Ogre::LL_NORMAL;
		ogreInitialized_ = false;
		dummyWindow_ = NULL;
		render_ = true;

		try {
			rageKERNELLOG << "Creating Ogre::Root.";
			root_ = new Ogre::Root("","","");
			rageKERNELLOG << "Done creating Ogre::Root.";
		} catch(Ogre::Exception& e) {
			rageKERNELLOG << rageERROR << e.what();
			return;
		}

		Ogre::Log* log;
		try {
			log = Ogre::LogManager::getSingleton().createLog("ogrePlugin", true, true, true);
			log->addListener(this);
			log->setLogDetail(ogreLogLevel_);
		} catch (Ogre::Exception& e) {
			ragePLUGINLOG << rageERROR << "Exception thrown while setting up ogre logging: " << e.getFullDescription();
			return;
		}

	}
	~PIMPL() {
		if (dummyWindow_ != NULL) {
			// destroy the dummy window
			dummyWindow_->finalizeOgre();
			dummyWindow_->Destroy();
		}

		// destroy all the render windows
		std::vector<OgreMDIChildFrame*>::iterator it = renderTargets_.begin();
		while (it != renderTargets_.end()) {
			(*it)->Destroy();
			++it;
		}

		// finalize ogre
		delete root_;
	}

	void setupOgre();

	// Ogre's Log Listener implementation
	void messageLogged(const Ogre::String &message, Ogre::LogMessageLevel lml, bool maskDebug, const Ogre::String & logName);


	volatile bool windowCreationFinished_;
	volatile bool disconnectIdleLoop_;
	std::string currWindowName_;
	int currWidth_, currHeight_;
	std::vector<OgreMDIChildFrame*>  renderTargets_;
	wxDummyOgreCtrl*		dummyWindow_;
	std::string ogrePluginFolder_;
	std::string                     rss_;
	std::vector<rssParamTp>			rssParameters_;
	std::vector<std::string>        ogrePlugins_;


	Ogre::LoggingLevel   ogreLogLevel_;
	Ogre::Root*          root_;
	Ogre::SceneManager*  sceneManager_;
	Ogre::RaySceneQuery* raySceneQuery_;
	volatile bool ogreInitialized_;
	OgreMainWindow* gui_;
	bool render_;

};

void OgreMainWindow::PIMPL::messageLogged(const Ogre::String &message, Ogre::LogMessageLevel lml, bool maskDebug, const Ogre::String & logName) {
	switch (lml) {
		case Ogre::LML_CRITICAL:
			rageKERNELLOG << rageERROR << message;
			break;
		case Ogre::LML_NORMAL:
		case Ogre::LML_TRIVIAL:
			rageKERNELLOG  << message;
			break;
	}
}

OgreMainWindow::OgreMainWindow() : wxMDIParentFrame() {
}

OgreMainWindow::OgreMainWindow(wxWindow *parent,
                 const wxWindowID id,
                 const wxString& title,
                 const wxPoint& pos,
                 const wxSize& size,
                 const long style)
       : wxMDIParentFrame(parent, id, title, pos, size, style) 
{

	pImpl_ = new PIMPL(this);
	RAGE::Kernel::instance()->setOgreMainWindow(this);

	// Make a menubar
    wxMenuBar *menu_bar = new wxMenuBar;
	view_menu_ = new wxMenu();
	menu_bar->Append(view_menu_, "&View");

    // Associate the menu bar with the frame
    this->SetMenuBar(menu_bar);

	this->Connect(wxEVT_IDLE, wxIdleEventHandler(OgreMainWindow::OnIdle));

}

void OgreMainWindow::waitForOgreInitialized() {
	while (!pImpl_->ogreInitialized_)
		Sleep(100);
}


OgreMainWindow::~OgreMainWindow() {
}

void OgreMainWindow::OnClose(wxCloseEvent& event)
{
	delete pImpl_;
}

void OgreMainWindow::createWindow(const std::string& title, int width, int height) {
	pImpl_->currWindowName_ = title;
	pImpl_->currWidth_ = width;
	pImpl_->currHeight_ = height;
	pImpl_->windowCreationFinished_ = false;

}

/*std::vector<OgreMDIChildFrame*> OgreMainWindow::getAllRenderTargets() const {
	return pImpl_->renderTargets_;
}*/


void OgreMainWindow::disconnectIdleLoop() {
	pImpl_->disconnectIdleLoop_ = true;
}


void OgreMainWindow::OnIdle(wxIdleEvent& WXUNUSED(event)) {
	//rageKERNELLOG << "In idle loop";
	if (pImpl_->disconnectIdleLoop_) {
		this->Disconnect(wxEVT_IDLE, wxIdleEventHandler(OgreMainWindow::OnIdle));
		return;
	}

	if (!pImpl_->windowCreationFinished_) {

		if (!pImpl_->ogreInitialized_) {
			pImpl_->setupOgre();
		}

		// create an MDI child frame
		OgreMDIChildFrame* childCreated = new OgreMDIChildFrame(this,
			wxID_ANY,
			pImpl_->currWindowName_,
			wxDefaultPosition,
			wxSize(pImpl_->currWidth_,pImpl_->currHeight_), 
			wxMINIMIZE_BOX | wxMAXIMIZE_BOX | wxTHICK_FRAME | wxSYSTEM_MENU | wxCAPTION | wxMAXIMIZE,
			pImpl_->currWindowName_, pImpl_->sceneManager_);

		// save it in the window map
		pImpl_->renderTargets_.push_back(childCreated);
		pImpl_->windowCreationFinished_ = true;

		childCreated->Show();

		// Add a show/hide event handler
		const long itemID = wxNewId();
		wxMenuItem* item = view_menu_->AppendCheckItem(itemID,pImpl_->currWindowName_);
		item->Check(true);
		this->Connect(itemID,wxEVT_COMMAND_MENU_SELECTED,wxCommandEventHandler(OgreMainWindow::OnShowHideChildFrame));

	}

	// render the frames for all the viewers
	if (pImpl_->render_) {
		std::vector<OgreMDIChildFrame*>::iterator it = pImpl_->renderTargets_.begin();
		while (it != pImpl_->renderTargets_.end()) {
			Ogre::Root::getSingletonPtr()->_fireFrameStarted();
			(*it)->update();
			Ogre::Root::getSingletonPtr()->_fireFrameEnded();
			++it;
		}
	}

}

void OgreMainWindow::OnSize(wxSizeEvent& WXUNUSED(event))
{
    wxLayoutAlgorithm layout;
    layout.LayoutMDIFrame(this);
}

void OgreMainWindow::OnShowHideChildFrame(wxCommandEvent& event) {

	std::vector<OgreMDIChildFrame*>::iterator it = pImpl_->renderTargets_.begin();
	while (it != pImpl_->renderTargets_.end()) {
		int itemid = view_menu_->FindItem((*it)->GetLabel());
		wxMenuItem* item = view_menu_->FindItem(itemid);
		if (item->IsChecked()) {
			(*it)->Show(true);
			//pluginGUI_->onShown(it->first);
		} else {
			(*it)->Show(false);
			//pluginGUI_->onHidden(it->first);
		}
		++it;
	}
}

/*void OgreMainWindow::OnCreate( wxWindowCreateEvent& event) {
	rageKERNELLOG << "Window created." << event.GetId() << ", this id = " << this->GetId();
}*/


void OgreMainWindow::updateMenuChildFrameShowHide(const wxString& title) {
	int itemid = view_menu_->FindItem(title);
	wxMenuItem* item = view_menu_->FindItem(itemid);
	/*WINDOWID win = pluginGUI_->getWindowIDFromTitle(title.c_str());
	if (pluginGUI_->windows_[win]->IsShown())
		item->Check(true);
	else
		item->Check(false);*/
}

/*void OgreMainWindow::OnCreatePluginMDIChild(wxCommandEvent& event) {
	rageKERNELLOG << "Inside OnCreatePluginMDIChild";
}
*/


/*void PluginMainWindow::destroyMDIChild(const std::string& title) {
}
*/

Ogre::SceneManager* OgreMainWindow::getSceneManager() const { 
	return pImpl_->sceneManager_; 
}

Ogre::Root* OgreMainWindow::getRoot() const {
	return pImpl_->root_;
}

wxOgreCtrl* OgreMainWindow::getRenderTarget(const std::string& title) {
	std::vector<OgreMDIChildFrame*>::iterator it = pImpl_->renderTargets_.begin();
	while (it != pImpl_->renderTargets_.end()) {
		if ((*it)->GetTitle() == title)
			return (*it)->getRenderTarget();
	}
	throw rageKERNELEXCEPTION("Render target of title " + title + " not found.");

}


void OgreMainWindow::setCameraPosition(const std::string& title, double x, double y, double z){
	wxOgreCtrl* wxWindow = getRenderTarget(title);
	wxWindow->setCameraPosition(x, y, z);
	pImpl_->sceneManager_->getCurrentViewport()->setBackgroundColour(Ogre::ColourValue(0.5,0.5,0.5));
}

void OgreMainWindow::setCameraDirection(const std::string& title, double x, double y, double z){
	wxOgreCtrl* wxWindow = getRenderTarget(title);
	wxWindow->setCameraDirection(x, y, z);
}

void OgreMainWindow::setCameraLookAt(const std::string& title, double x, double y, double z){
	wxOgreCtrl* wxWindow = getRenderTarget(title);
	wxWindow->setCameraLookAt(x, y, z);
}

void OgreMainWindow::enableRendering(const bool& render) {
	pImpl_->render_ = render;

}

MATH::Vector3D OgreMainWindow::doIntersectionWithGroundPlane(const std::string& title, int x, int y){
		
	wxOgreCtrl* wxWindow = getRenderTarget(title);
	Ogre::Camera* cam = wxWindow->getCamera();
	MATH::Vector3D resultVec;

	//x and y should be normalized!
	int w = 0;
	int h = 0;
	wxWindow->GetSize(&w,&h);
	double normalizedX = double(x) / double(w);
	double normalizedY = double(y) / double(h);

	Ogre::Ray mouseRay = cam->getCameraToViewportRay( normalizedX, normalizedY);

	Ogre::Vector3 camdir = cam->getDirection();
	Ogre::Quaternion camor = cam->getOrientation();
	Ogre::Vector3 campos = cam->getPosition();

	Ogre::Vector3 camdir2 = cam->getDerivedDirection();
	Ogre::Quaternion camor2 = cam->getDerivedOrientation();
	Ogre::Vector3 campos2 = cam->getDerivedPosition();
	
	Ogre::Vector3 dir = mouseRay.getDirection();
	Ogre::Vector3 orig = mouseRay.getOrigin();
	
	Ogre::Plane plane(Ogre::Vector3(0, 1, 0), Ogre::Vector3(0, 0, 0));
	std::pair<bool, Ogre::Real> pair =  Ogre::Math::intersects(mouseRay, plane);
	if(pair.first){
		Ogre::Vector3 intersect = mouseRay.getPoint(pair.second);
		resultVec.x = intersect.x;
		resultVec.y = intersect.y;
		resultVec.z = intersect.z;
	}
	else{
		rageLIBLOG << rageERROR << "No intersection";
	}

	

	return resultVec;        
	
}

MATH::Vector3D OgreMainWindow::doIntersection(const std::string& title, int x, int y){
	 // Setup the scene query

	wxOgreCtrl* wxWindow = getRenderTarget(title);
	Ogre::Camera* cam = wxWindow->getCamera();

		//x and y should be normalized!
	int w = 0;
	int h = 0;
	wxWindow->GetSize(&w,&h);
	double normalizedX = double(x) / double(w);
	double normalizedY = double(y) / double(h);

	Ogre::Ray mouseRay = cam->getCameraToViewportRay( normalizedX, normalizedY);
	        
	//Ogre::Ray mouseRay(cam->getDerivedPosition(), cam->getDerivedDirection());
	
	pImpl_->raySceneQuery_->setRay( mouseRay );
	pImpl_->raySceneQuery_->setSortByDistance( true );

	Ogre::Vector3 campos = cam->getPosition();
	rageLIBLOG << "Doing intersection at x: " << x << " y: " << y << " with camera pos: (" << campos.x << " ," << campos.y << " ," << campos.z;

    // Perform the scene query
	Ogre::RaySceneQueryResult &result = pImpl_->raySceneQuery_->execute();
    Ogre::RaySceneQueryResult::iterator itr = result.begin( );

	MATH::Vector3D resultVec;
    // Get the results, neglect collision with distance 0, then we are already in the bounding 
	// box of that object.

	while(itr != result.end()  ) 
    {
		double dist = itr->distance;
		
		if(dist == 0){ //we are already inside a bounding box
			itr++;
			continue;
		}
		
		if(itr->worldFragment){
			ragePLUGINLOG << "Collision with world fragment at distance: " << dist;
			
			resultVec.x = itr->worldFragment->singleIntersection.x;
			resultVec.y = itr->worldFragment->singleIntersection.y;
			resultVec.z = itr->worldFragment->singleIntersection.z;
			break;
		}
		else if(itr->movable){
			ragePLUGINLOG << "Collision with movable: " << itr->movable->getName() << " at distance: " << dist;
			
			//movable intersection does not provide intersection point, manually determine
			Ogre::Vector3 origin = mouseRay.getOrigin(); 
			Ogre::Vector3 direction = mouseRay.getDirection();
			Ogre::Real direction_length = direction.length();
			direction/=direction_length; // unit vector

			Ogre::Vector3 objPosition = origin + (direction * dist); 
			resultVec.x = objPosition.x;
			resultVec.y = objPosition.y;
			resultVec.z = objPosition.z;
			break;
		}

		itr++;
	}


	return resultVec;        

}








///*****************************
/// OGRE SETUP FUNCTIONS
///*****************************

void OgreMainWindow::addRenderingSubSystemParameter(const std::string& subsystem, const std::string& name, const std::string& value) {
	pImpl_->rssParameters_.push_back(rssParamTp(subsystem,name,value));
}

void OgreMainWindow::setRenderingSubSystem(const std::string& rss) {
	pImpl_->rss_ = rss;
}

void OgreMainWindow::setOgrePluginFolder(const std::string& folder) {
	pImpl_->ogrePluginFolder_ = folder;
}

void OgreMainWindow::setOgreLogLevel(const std::string& level) {
	if (level == "normal")
		pImpl_->ogreLogLevel_ = Ogre::LL_NORMAL;
	else if (level == "low")
		pImpl_->ogreLogLevel_ = Ogre::LL_LOW;
	else if (level=="boreme") 
		pImpl_->ogreLogLevel_ = Ogre::LL_BOREME;
	else
		rageLOG << rageWARNING << "Unknown ogre logging level: " << level;
}

void OgreMainWindow::addOgrePlugin(const std::string& pluginName) {
	pImpl_->ogrePlugins_.push_back(pluginName);
}

void OgreMainWindow::addResourceLocation(const std::string& name, const std::string& type, const std::string& group) {
	try {
		Ogre::ResourceGroupManager::getSingleton().addResourceLocation(name, type, group);
	} catch (Ogre::Exception& e) {
		ragePLUGINLOG << rageERROR << "Unable to add Ogre Resource location: " << e.getFullDescription();
		return;
	}
}

void OgreMainWindow::PIMPL::setupOgre() {

	// setup plugins
	rageKERNELLOG << "Setting up the Ogre plugins...";

	// add extra slash in case plugin folder doesn't contain one
	char last_char = ogrePluginFolder_[ogrePluginFolder_.length()-1];
	if (last_char != '/' && last_char != '\\')
		ogrePluginFolder_ += "\\";

	// load the plugins
	std::vector<std::string>::iterator it = ogrePlugins_.begin();
	while (it != ogrePlugins_.end()) {
		try {
			//root_->loadPlugin(ogrePluginFolder_ + *it);
			root_->loadPlugin(*it);
		} catch (Ogre::Exception& e) {
			ragePLUGINLOG << rageERROR << "Exception thrown during loading of Ogre plugins: " << e.getFullDescription();
		} catch (RAGE::Exception& e) {
			ragePLUGINLOG << rageERROR << "Exception thrown during loading of Ogre plugins: " << e.getMessage();
		}
		++it;
	}
	rageKERNELLOG << "Done setting up the Ogre plugins.";

	// setup config
	rageKERNELLOG << "Setting up Ogre configuration...";

	// set the render subsystem parameters
	try {

		std::vector<rssParamTp>::iterator it = rssParameters_.begin();

		while (it != rssParameters_.end()) {
			Ogre::RenderSystem* rs = root_->getRenderSystemByName(it->subsystem_);
			if (!rs)
				throw ragePLUGINEXCEPTION("Ogre Rendering System not found.");
			rs->setConfigOption(it->name_,it->value_);
			++it;
		}

	} catch (Ogre::Exception& e) {
		rageKERNELLOG << rageERROR << "Error while setting options of Ogre Render System: " << e.getFullDescription();
		return;
	} catch (RAGE::Exception& e) {
		rageKERNELLOG << rageERROR << "Error while setting options of Ogre Render System: " << e.getMessage();
		return;
	}

	// now set the current render system
	try {
		if (rss_ != "") {
			Ogre::RenderSystem* rs = root_->getRenderSystemByName(rss_);
			if (!rs)
				throw rageKERNELEXCEPTION("Ogre Rendering System not found while setting render system.");
			root_->setRenderSystem(rs);
		}
	} catch (Ogre::Exception& e) {
		rageKERNELLOG << rageERROR << "Exception thrown during setting of rendering system: " << e.getFullDescription();
	}

	rageKERNELLOG << "Done setting up Ogre configuration.";

	rageKERNELLOG << "Initializing Ogre Root";
	try {
		root_->initialise(false);
	} catch (Ogre::Exception& e) {
		ragePLUGINLOG << rageERROR << "Could not initialize the root: " << e.getFullDescription();
		return;
	}

	// Create a dummy window
	dummyWindow_ = new wxDummyOgreCtrl(gui_);
	
	ragePLUGINLOG << "Creating Ogre Scenemanager";
	try {
		sceneManager_ = root_->createSceneManager(Ogre::ST_GENERIC, "default");
	} catch (Ogre::Exception& e) {
		ragePLUGINLOG << rageERROR << "Could not create scene manager: " << e.getFullDescription();
		return;
	}

	ragePLUGINLOG << "Initializing resource groups";
	try {
		Ogre::ResourceGroupManager::getSingleton().initialiseAllResourceGroups();
	} catch(Ogre::Exception& e) {
		ragePLUGINLOG << rageERROR << "Unable to initialize Ogre Resource groups: " << e.getFullDescription();
	}

	ragePLUGINLOG << "Setting up collision detection";
	raySceneQuery_ = sceneManager_->createRayQuery( Ogre::Ray() );


	ragePLUGINLOG << "Done initializing ogre (ogre root=" << root_ << ")";

	ogreInitialized_ = true;
}

}




