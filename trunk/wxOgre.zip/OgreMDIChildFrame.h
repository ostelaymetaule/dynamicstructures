#ifndef OgreMDIChildFrame_H_
#define OgreMDIChildFrame_H_

#include <wx/wx.h>

#include <rage/rageTypes.h>
#include <string>

namespace Ogre {
	class SceneManager;
}

class wxOgreCtrl;

namespace RAGE {

class OgreMDIChildFrame : public wxMDIChildFrame {
public:

	OgreMDIChildFrame() {}

    OgreMDIChildFrame(wxMDIParentFrame* parent, 
				wxWindowID id, 
				const wxString& title, 
				const wxPoint& pos = wxDefaultPosition, 
				const wxSize& size = wxDefaultSize, 
				long style = wxMINIMIZE_BOX | wxMAXIMIZE_BOX | wxTHICK_FRAME | wxSYSTEM_MENU | wxCAPTION | wxMAXIMIZE, 
				const wxString& name = wxFrameNameStr,
				Ogre::SceneManager* sceneManager = NULL);

	virtual ~OgreMDIChildFrame();

    void OnClose(wxCloseEvent& event);

	void update();
	wxOgreCtrl* getRenderTarget();

    DECLARE_EVENT_TABLE()

private:

	wxOgreCtrl* renderTarget_;
};

}

#endif
